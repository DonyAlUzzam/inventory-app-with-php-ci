-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Waktu pembuatan: 16 Okt 2019 pada 06.43
-- Versi server: 10.3.16-MariaDB
-- Versi PHP: 7.1.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stok`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `history`
--

CREATE TABLE `history` (
  `id` int(11) NOT NULL,
  `partNumber` varchar(20) NOT NULL,
  `qty_keluar` int(10) NOT NULL,
  `keterangan` text NOT NULL,
  `pic` varchar(20) NOT NULL,
  `created_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `history`
--

INSERT INTO `history` (`id`, `partNumber`, `qty_keluar`, `keterangan`, `pic`, `created_date`) VALUES
(7, 'Tes', 4, '', '', '2019-09-10'),
(9, 'Tes', 1, 'asdsad', 'sadasd', '2019-10-15'),
(10, 'Tes', 2, 'adasdaadasd', 'dadas', '2019-10-15'),
(16, 'Testing22', 0, '', '', '0000-00-00'),
(17, 'Testing22', 5, 'asead', 'dsd', '2019-10-15'),
(18, '3223a', 0, '', '', '0000-00-00'),
(19, '3223a', 10, 'dsadasd', 'sfsfds', '2019-10-16');

-- --------------------------------------------------------

--
-- Struktur dari tabel `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `user` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `login`
--

INSERT INTO `login` (`id`, `user`, `pass`) VALUES
(2, 'admin', '21232f297a57a5a743894a0e4a801fc3'),
(5, 'coba', '1621a5dc746d5d19665ed742b2ef9736'),
(6, '', '0192023a7bbd73250516f069df18b500'),
(7, '', '0192023a7bbd73250516f069df18b500'),
(8, '', '0192023a7bbd73250516f069df18b500'),
(9, '', '0192023a7bbd73250516f069df18b500'),
(10, '', '0192023a7bbd73250516f069df18b500'),
(11, '', '0192023a7bbd73250516f069df18b500'),
(12, '', '0192023a7bbd73250516f069df18b500'),
(13, '', '0192023a7bbd73250516f069df18b500'),
(14, '', '0192023a7bbd73250516f069df18b500'),
(15, '', '0192023a7bbd73250516f069df18b500'),
(16, '', '0192023a7bbd73250516f069df18b500');

-- --------------------------------------------------------

--
-- Struktur dari tabel `product`
--

CREATE TABLE `product` (
  `partNumber` varchar(20) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `qty_masuk` int(10) NOT NULL,
  `created_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `product`
--

INSERT INTO `product` (`partNumber`, `nama`, `qty_masuk`, `created_date`) VALUES
('3223a', 'dsada', 22, '2019-10-16'),
('Tes', 'tes', 12, '2019-10-15'),
('Testing22', 'testing', 23, '2019-10-15');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`partNumber`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `history`
--
ALTER TABLE `history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT untuk tabel `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
